Requirement

The requirement as follows:
Name 	Version
cuda 	8.0
python 	3.5
pytorch 	0.3.1


Dataset

Our method can be evaluated on MOT17, MOT15 and UA-DETRAC.

    MOT15 and MOT17 is for pedestrian tracking.

    UA-DETRAC focuses is for vehicle tracking.



